import AboutPage from "@/app/about/page";

export default function AboutPageStoryboard() {
  return <AboutPage />;
}